label dimensionalCompressor:
    s "Engine troubles eh? I figured that was your problem when I saw your ship outside."
    s "It's a fine ship, but by the shape of the hull, I'm guessing you have a Kaluza compressor in there."
    s "They can do some serious spatial bending, but are pretty volatile."
    s "Not to worry, I have a great replacement for you right here. 10000 credits and its all yours."
    menu:
        "I'll take it":
            jump dimFirstPrice
        "The absolute maximum I can spend is 7500 credits":
            jump dimOfferMax
        "Would you mind if I took a look at it first?":
            jump dimShow
        "I want it for 500 credits":
            jump dimWayTooLow
        "What about 3225 credits?":
            jump dimSpecificHaggle
        "Can you tell me anything more about the compressor?":
            jump dimSpiel
        "Call it 8000 credits and I'll take it right now":
            jump dimTinyDeal
        "Thats far more than I intended to spend... How about 5000 credits?":
            jump dimMidHaggle

label dimFirstPrice:
    play sound "sounds/kaChing.mp3"
    s "Wonderful!"
    s "Best quality compressor you'll find anywhere around here."
    s "Is there anything else I can get for you?"
    $ dim = True
    $ dim_price = 10000
    
    jump buyingOptions

label dimOfferMax:
    s "Thats a pretty large discount..."
    s "I guess you need to get off this planet somehow right?"
    s "..."
    s "...Ok fine, you've got yourself a deal."
    menu:
        "Can you go any lower? What about 7000 credits?":
            jump dimRefuseLowerMax
        "Great! I'll take it":
            jump dimMaxDeal

label dimRefuseLowerMax:
    s "No. I don't think I can go any lower."
    s "Do you want it or not?"
    menu:
        "Ok fine":
            jump dimMaxDeal

label dimMaxDeal:
    play sound "sounds/kaChing.mp3"
    s "Glad I could help you out."
    s "Anything else?"
    $ dim = True
    $ dim_price = 7500
    
    jump buyingOptions
    

label dimShow:
    s "Of course, always a wise thing to ask."
    s "Never transfer a single credit for something you haven't seen."
    s "Take a look at this beauty:"
    show bg shopEngineDetail
    "The Karuza-Klein VS Spatial Compression Engine. The casing looks a little dulled and has a few scratches, but otherwise it looks of good quality."
    
    show bg shop
    s "Let me talk you through what this thing can do..."
    $ dent_noticed = True
    menu:
        "I'm listening...":
            jump dimSpiel
        "Don't worry about it, i'm ready to buy it":
            jump dimFirstPrice
        "I want it, but really the highest I can go is 7500 credits":
            jump dimOfferMax
        "I'll give you 3225 credits for that":
            jump dimSpecificHaggle
        "If you are able to do a deal for 8000 credits, i'll take it right now":
            jump dimTinyDeal
        "It looks good, but its still far more than I intended to spend. Could you stretch to 5000 credits?":
            jump dimMidHaggle

label dimWayTooLow:
    s "I'm sure you do!"
    s "You can't expect me to believe you've travelled all around this galaxy and have never seen the price of a compression engine before."
    s "Walk into a parts seller anywhere in the galaxy and ask them to give you a compressor for 500 credits. You will be laughed out."
    s "10000 credits is the price, thats what I'm selling it for."
    menu:
        "There is no way I could find anyone in the galaxy that charges what you charge. You're a thief  to ask for 10000":
            jump dimThiefAccusation
        "Fine. I'll pay 10000 I guess":
            jump dimFirstPrice

label dimThiefAccusation:
    s "Thief?"
    s "..."
    s "You people come from off-planet,"
    s "Saunter into my town,"
    s "MY shop,"
    s "And accuse me of being a criminal?"
    s "Why don't you just get the hell out of my store? I wouldn't sell this to you if you offered me 10000000 credits!"
    jump thrownOutEnding

label dimSpecificHaggle:
    s "Thats an incredibly specific price."
    s "I mean its far too low of course..."
    s "But maybe you'd also like to share the genius behind that calculation?"
    menu:
        "I don't know. It just feels like right price":
            jump dimNoExplanation
        "Most places sell dimensional compressors around that price range. That was around what I paid for the last one I bought":
            jump dimLastPaidExplanation
        "I really need this part!":
            jump dimExplanationDesperate
        "Well, I was going to offer the market price, but seeing as this one looks a bit dented, I deducted 15\% from what I usually pay" if dent_noticed:
            jump dimStrongExplanation
        "Call it a round 3500 credits then":
            jump dimRoundUp

label dimNoExplanation:
    s "Well I can't run my business based on your gut feelings!"
    s "My prices are based on objective value. 10000 is the best I can sell it for"
    menu:
        "Very well...":
            jump dimBuyWithNoExplanation
        
label dimBuyWithNoExplanation:
    play sound "sounds/kaChing.mp3"
    s "There you go!"
    s "Anything else?"
    $ dim = True
    $ dim_price = 10000
    
    jump buyingOptions

label dimLastPaidExplanation:
    s "Well it certainly won't have been as good quality as this one."
    s "Aren't you in here because your last one engine burned out?"
    s "I can sell it to you for 8500 credits. That's reasonable, right?"
    menu:
        "Hmm...I'm really not sure about that":
            jump dimMidHaggleHesitation
        "Very well, I guess if thats the best you can do":
            jump dimFirstMidHaggleAccept
        "6500!":
            jump dimMidHaggleAnchoring
        "Seems fair. 8500 credits it is":
            jump dimFirstMidHaggleAccept
            
label dimFirstMidHaggleAccept:
    play sound "sounds/kaChing.mp3"
    s "Good choice."
    s "Anything else I can get you?"
    $ dim = True
    $ dim_price = 8500
    
    jump buyingOptions

label dimExplanationDesperate:
    s "If you really need it, you should offer a realistic price!"
    s "I can knock 1000 credits off it, seeing as you seem desperate."
    menu:
        "Fine":
            jump dimBuyDesperate

label dimBuyDesperate:
    play sound "sounds/kaChing.mp3"
    s "Glad I could help you out."
    s "Anything else?"
    $ dim = True
    $ dim_price = 9000
    
    jump buyingOptions
    
label dimStrongExplanation:
    s "No no no! My good friend, I assure you this is a quality compressor."
    s "When you're buying a robust piece of technology like this, you have to look past cosmetic blemishes."
    s "Tell you what though, I'll give you it for 7200 credits if it will keep you happy."
    s "You have to agree, thats a massive discount."
    menu:
        "Okay, you have a deal":
            jump dimStrongBuyFirstPrice
        "I want a compressor, but at that price I'm not sure I'm interested":
            jump dimStrongDisinterest

label dimStrongBuyFirstPrice:
    play sound "sounds/kaChing.mp3"
    s "Great decision."
    s "And I assure you, it really really is a top quality compressor. If it so much as stutters in the next year, come back to me and I'll replace it free of charge."
    s "Anything else?"
    $ dim = True
    $ dim_price = 7200
    jump buyingOptions

label dimStrongDisinterest:
    s "Where the do you get off?"
    s "You come in here, insult my merchandise..."
    s "Then demand some insane discount. If you want it, take it at the price I gave!"
    menu:
        "I'm sorry, I wasn't trying to be rude. I'm more than happy to pay 7200 credits":
            jump dimIntimidatedBuy
        "You need to calm down buddy. This is a business negotiation, don't get so emotional":
            jump dimBadHumour
        "That's what us space traders are all about! We love the thrill of a good deal. Shall we say 5100 credits then?":
            jump dimGoodHumour

label dimIntimidatedBuy:
    play sound "sounds/kaChing.mp3"
    s "Well...apology accepted I suppose."
    s "Try not to be so demanding of people when you are a guest on a foreign planet."
    s "Is there anything else you need?"
    $ dim = True
    $ dim_price = 10000
    
    jump buyingOptions

label dimBadHumour:
    "Don't you tell ME to calm down! I don't have to take insults and low-ball pricing from some imperialist shipper!"
    "Just leave. Ie don't need your custom here."
    jump thrownOutEnding
    
label dimGoodHumour:
    s "I know! You traders are always squeezing me..."
    s "Fine, 5600 credits and we shake hands now. You'll close down my shop at this rate."
    menu:
        "A great deal my friend, Ill take it":
            jump dimLowestPriceBuy
        "How do you feel about throwing in some other stuff to sweeten the deal?" if (not y_gas) or (not ZwrG):
            jump multiBuyOffer

label dimLowestPriceBuy:
    play sound "sounds/kaChing.mp3"
    s "Thank goodness. Your stubborness was making me wonder if you even wanted the engine!"
    s "Anything else?"
    $ dim = True
    $ dim_price = 5600
    
    jump buyingOptions

label multiBuyOffer:
    s "You really are a deal hunter."
    s "Well, you brought it up, what else do you want?"
    menu:
        "I need 250ml of Y-Gas. Lets do a deal on both" if not y_gas:
            jump dimYGasBundle
        "I need some ZwrG connectors. Throw them in for free and we've got a deal" if not ZwrG:
            jump dimZwrGBundle
        "Actually never mind, I will just take the compressor for 5600 credits":
            jump dimLowestPriceBuy

label dimYGasBundle:
    s "Let me think..."
    s "I can do the Y-Gas and compressor for...6000 credits total. How about that?"
    menu:
        "Nevermind, I will just take the compressor for 5600":
            jump dimLowestPriceBuy
        "Deal, I'll take both for 6000":
            jump YGasHighBundleBuy
        "5800 credits":
            jump YGasLow

label YGasHighBundleBuy:
    play sound "sounds/kaChing.mp3"
    s "Fantastic. You're really getting a fine deal."
    s "Anything else I can get you?"
    $ dim = True
    $ dim_price = 5600
    $ y_gas = True
    $ y_gas_price = 400
    
    jump buyingOptions

label YGasLow:
    play sound "sounds/kaChing.mp3"
    s "Oh fine, take it! I can't stand your persistence. You've exhausted me."
    s "Any other products you want to whittle me down on?"
    $ dim = True
    $ dim_price = 5600
    $ y_gas = True
    $ y_gas_price = 200
    
    jump buyingOptions

label dimZwrGBundle:
    play sound "sounds/kaChing.mp3"
    s "Consider it done."
    s "Anything else?"
    $ ZwrG = True
    $ ZwrG_price = 0
    
    jump buyingOptions

label dimRoundUp:
    s "That's still a pretty wild number, even if it's easier to work with"
    s "I can sell it to you for 8500 credits, that's a little more reasonable, right?"
    menu:
        "Hmm...I'm really not sure about that":
            jump dimMidHaggleHesitation
        "Very well, I guess if thats the best you can do":
            jump dimFirstMidHaggleAccept
        "6500!":
            jump dimMidHaggleAnchoring
        "Seems fair. 8500 credits it is":
            jump dimFirstMidHaggleAccept

label dimSpiel:
    s "Its hard to go wrong with the Kaluza model. There's a reason they've been producing it for three decades now."
    s "Tight spatial compression, good fuel efficiency, smooth recalibration..."
    s "People always complain that it's more expensive than the Higgler models, but it's well worth the price."
    s "Those Higgler compressors are notorious for their knockback after dimensional re-sync. With the Kaluza, it's just not an issue."
    menu:
        "I've heard all I need to hear. Lets make a deal":
            jump dimHeardEnough
        "(Let the shopkeeper continue)":
            jump dimContinueSpiel

label dimHeardEnough:
    s "I really can't stress what a great compressor it is. I think you'll agree that 10000 credits is a more than generous price"
    menu:
        "Agreed, I'll take it":
            jump dimFirstPrice
        "I want it, but my max price is 7500 credits":
            jump dimOfferMax
        "I'll give you 3225 credits for it":
            jump dimSpecificHaggle
        "If you are able to stretch to 8000 credits, I'll take it right now":
            jump dimTinyDeal
        "It sounds good, but it's still far more than I intended to spend. How about 5000?":
            jump dimMidHaggle

label dimContinueSpiel:
    s "Listen to that steady whir when it starts up."
    s "That's the sound of millenia of physics knowledge, harnessed to work for today's economy"
    s "The minute you hook this up to your ship, you unlock every shortcut between every point in the universe!"
    s "Don't worry about fitting it. I'll set it up for your right now. We can sort out the 10000 credits once it's all installed"
    menu:
        "Uh...Ok I guess?":
            jump dimBuyConfusedBySpiel

label dimBuyConfusedBySpiel:
    play sound "sounds/kaChing.mp3"
    s "Excellent. Is there anything else I can do for you?"
    $ dim = True
    $ dim_price = 10000
    
    jump buyingOptions
        
label dimTinyDeal:
    play sound "sounds/kaChing.mp3"
    s "Hmm..."
    s "Oh fine 8000 credits, but only because I like you."
    s "Anything else?"
    $ dim = True
    $ dim_price = 8000
    
    jump buyingOptions
    

label dimMidHaggle:
    s "Oh no, this isn't a jet engine you're buying. This machine compresses dimensions!"
    s "I'll give you it for 8500 credits if you promise not to tell any other traders I went this low."
    menu:
        "Hmm...I'm really not sure about that":
            jump dimMidHaggleHesitation
        "Very well, I guess if thats the best you can do":
            jump dimFirstMidHaggleAccept
        "6500!":
            jump dimMidHaggleAnchoring
        "Seems fair. 8500 it is":
            jump dimFirstMidHaggleAccept

label dimMidHaggleHesitation:
    s "Ok 7000 credits. You are a hard customer to satisfy!"
    menu:
        "Deal":
            jump dimHesitationAccept
        "Call it 6000 credits and then we're talking":
            jump dimHesitationAndHaggle

label dimHesitationAccept:
    play sound "sounds/kaChing.mp3"
    s "Finally! Ever considered a career in buying and selling? I think you would be at home there."
    s "7000 credits it is, anything else?"
    $ dim = True
    $ dim_price = 7000
    
    jump buyingOptions

label dimHesitationAndHaggle:
    s "You just don't give up do you? Ok 6500 credits and we shake hands right now."
    menu:
        "You have yourself a deal":
            jump dimBestAnchoredDeal

label dimBestAnchoredDeal:
    play sound "sounds/kaChing.mp3"
    s "You're shrewd, I'll give you that. No loose credits escaping from you."
    s "Anything else?"
    $ dim = True
    $ dim_price = 6500
    
    jump buyingOptions

label dimMidHaggleAnchoring:
    s "I appreciate your enthusiasm, but your bargaining style is merciless."
    s "I have a family to think about. I'm taking food off their table for every discount I give to you!"
    s "I can do 8000 credits, how about that?"
    menu:
        "7000 credits":
            jump dimMidHaggleAnotherAnchor
        "Fine, let's do it":
            jump dimMidHaggleFirstAnchorAccept

label dimMidHaggleFirstAnchorAccept:
    play sound "sounds/kaChing.mp3"
    s "At last! Some mercy."
    s "There you go."
    s "Anything else?"
    $ dim = True
    $ dim_price = 8000
    
    jump buyingOptions
    
label dimMidHaggleAnotherAnchor:
    s "Oh it never ends with you does it?"
    s "7500 credits."
    s "...and that's really as far as I can go without you bankrupting me."
    menu:
        "Deal":
            jump dimHaggleAcceptAnotherAnchor

label dimHaggleAcceptAnotherAnchor:
    play sound "sounds/kaChing.mp3"
    s "There you go, anything else?"
    $ dim = True
    $ dim_price = 7500
    
    jump buyingOptions