label ZwrG:
    s "Ah of course. I take it you have a Kaluza engine in your ship?"
    s "The minute anything goes wrong with those compressors, they just frazzle the connectors as well."
    s "ZwrG connectors are pretty common though, I can sell you both for a credit each."
    menu:
        "Deal":
            jump buyZwrG
        "Can you do any better on that price?":
            jump ZwrGDiscount

label buyZwrG:
    play sound "sounds/kaChing.mp3"
    s "There you go, anything else?"
    $ ZwrG = True
    $ ZwrG_price = 2
    jump buyingOptions

label ZwrGDiscount:
    s "They're one credit each. You don't have two credits?"
    menu:
        "Actually, I have plenty of credits. Here you go.":
            jump buyZwrG
        "I'm buying two though. Let's just say a credit for the both of them":
            jump annoyedZwrG

label annoyedZwrG:
    s "Look friend, they're just connectors. It's not like I make a massive profit here."
    s "If you're asking me to sell them to you for half a credit each I might as well give them away for free."
    s "If you don't want them then don't buy them. It makes no difference to me."
    menu:
        "Fine, take your two credits":
            jump buyZwrG
        "Oh don't be such a miser. I'm an officer of the Trans-Lyria trade association. You should learn be more flexible.":
            jump ZwrGSpat

label ZwrGSpat:
    s "You know what? I don't think I need to have any flexibility."
    s "Not for some tight officer who insults me because he doesn't part with two credits for a couple of basic engine connectors."
    s "Just leave."
    jump thrownOutEnding