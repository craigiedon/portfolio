﻿define s = Character('Seller', color="#c8ffc8")
define m = Character('Me', color="#c8c8ff")

image bg shipEngine = Image("images/EngineBurnout.png")
image bg outside = Image("images/outside.png")
image bg shipDash = Image("images/shipDash.png")
image bg shopEngineDetail = ("images/shopEngineDetail.png")

image bg shop = ("images/shop.png")

image bg ending = ("images/Ending.png")

label start:
    $_game_menu_screen = None
    $ dim = False
    $ y_gas = False
    $ ZwrG = False
    
    $ dim_price = 0
    $ y_gas_price = 0
    $ ZwrG_price = 0
    
    $ cryo_price = 0
    $ dent_noticed = False
    
    scene bg shipDash
    pause
    m "Uh-oh. Those readings don't look good."
    m "Better land on a nearby planet and see whats wrong."
    
    scene bg outside
    pause
    m "Let's take a look under the hood."
    
    scene bg shipEngine
    pause
    m "Oh man, the {color=#f00}Dimensional Compressor {/color} is totally frazzled."
    m "It looks like the {color=#f00}ZwrG Connectors{/color} were destroyed in the process."
    m "I'm also out of {color=#f00}Y-Gas{/color} Fuel."    
    m "I still have a fair amount of credits on me. Maybe that store over there has what I need."
    m "I need: A new {color=#f00}Dimensional Compressor{/color}, Two {color=#f00}ZwrG Connectors{/color} to link it up to the rest of the ship, and {color=#f00}250ml Y-Gas{/color} to power it"
    m "I just hope it's not too expensive around here."
    
label market_intro:
    scene bg shop
    play music "sounds/maccaryBay.mp3"

    s "Good evening there friend. Welcome to \"Qubit Stellar Parts\"!"
    s "Is that a Trans-Lyria Uniform I see? What's a delivery officer doing out here?"
    s "No no, don't tell me. Cryo-Patches right? You've come to the right place."
    s "I've got a deal on right now. Ten for 750 credits."
    menu:
        "Sure, I could do with some Cryo-Patches":
            jump buyCryo
        "I'm okay actually. How are you doing? How is business?":
            jump askAboutDay
        "Actually, I'm looking for some parts for my ship":
            s "A good thing you came here then. What do you need? I've got every part you could need at bargain prices!"
            jump buyingOptions

label buyCryo:
    play sound "sounds/kaChing.mp3"
    s "Can never have enough packs right?"
    s "Honestly? I wouldn't want to be awake for a whole delivery job either."
    s "Do you need anything else?"
    $ cryo_price = 750
    
    menu:
        "Thats everything thanks":
            jump earlyLeaveWithJunk
        "Actually I am looking for some parts for my ship":
            s "What do you need? I've got every part ever made at bargain prices!"
            jump buyingOptions

label earlyLeaveWithJunk:
    s "You're welcome. Hope to see you again soon."
    scene bg outside
    m "Hold on a minute...I didn't get any of the parts I needed!"
    "THE END"
    return

label askAboutDay:
    s "Oh you know, ups and downs. The shop has been pretty busy ever since they lifted the embargo last month."
    s "Just as well, otherwise I wouldn't be able to help out shoppers like yourself! What can I get you?"
    jump buyingOptions

label buyingOptions:
    menu:
        "I need 250ml of Y-Gas" if not y_gas:
            jump yGas
        "I'm looking for a pair of ZwrG connectors" if not ZwrG:
            jump ZwrG
        "Do you happen to stock Dimensional Compressors?" if not dim:
            jump dimensionalCompressor
        "That's everything thanks" if y_gas and ZwrG and dim:
            jump boughtEverythingEnding

###################
##### ENDINGS #####
###################

label boughtEverythingEnding:
    s "You're welcome. Hope to see you again soon."
    
    scene bg ending
    
    $ total_price = dim_price + y_gas_price + ZwrG_price + cryo_price
    m "Well, I got all the parts I needed, and ended up paying [total_price] credits in total."
    if total_price >= 9002:
        m "Wow, I really got swindled in that place. I just used up all my profits from my last delivery. I bet that shopkeeper could've sold those parts to me for less."
        return
    if total_price >= 8002:
        m "Geez, it was expensive in there."
        m "I think if I'd pushed further, that shopkeeper would have given me a better deal."
        return
    if total_price >= 7002:
        m "Thats pretty reasonable. I would have paid around that price back home."
        m "Still...I wonder If I could have gotten a better deal if I'd pushed my luck further."
        return
    m "What a bargain! I should do business offworld more often."
    
    "THE END"
    return
    

label thrownOutEnding:
    scene bg outside
    m "Well that didn't go so great."
    m "That was the only shop on this planet that sold the parts I need to get home."
    m "Maybe I should watch my tone next time."
    "THE END"
    return

label disinterestEnding:
    scene bg outside
    m "I really needed those parts..."
    m "Why did I waste the seller's time with ludicrous offers?"
    "THE END"
    return