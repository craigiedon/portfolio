label yGas:
    s "Of course. Can't get very far without Y-Gas these days. It's the life-blood of inter-planetary trade."
    s "That's 800 credits for 250ml. I assume as a Trans Lyria trader you want premium filtered. Wouldn't want to damage your compressor with low grade junk fuel."
    menu:
        "Thanks, I'll take it":
            jump takePremium
        "Do you just have regular Y-Gas?":
            jump regularInquiry

label takePremium:
    play sound "sounds/kaChing.mp3"
    s "Good choice. We get a lot of younger traders coming through and filling up with the cheap Y-Gas. But it's a false economy if you ask me."
    s "They'll be back in a year complaining about how the poor synthesization has worn their compressor out."
    s "Anyway, is there anything else I can get for you?"
    $ y_gas = True
    $ y_gas_price = 800
    jump buyingOptions

label regularInquiry:
    s "Sure we've got plenty. The younger traders keep asking us to stock it."
    s "It's a little cheaper. But honestly? It's a false economy if you ask me."
    s "They don't bother to filter out TeVeS residue, so when the compressor tries to use the Y-gas to pull together space, it damages the engine internals."
    menu:
       "Well I don't want to wreck my compression engine. I'll take the premium stuff":
           jump takePremium
       "I've seen studies that say the stuff they put in premium to filter out that residue has just as bad an effect.
        It's about as beneficial as adding glitter to it.
        I'll take the regular.":
           jump knowsHisStuffNoPremium
       "Regular is fine":
           jump finalPremiumInsistence

label knowsHisStuffNoPremium:
    s "Ah, you've clearly done a bit of homework."
    s "Were you ever an engineer?"
    s "Well, if you prefer regular then that's fine with me. I make a sale either way."
    jump beginRegularSell
    
label finalPremiumInsistence:
    s "I'm not telling you this for the good of my health. I'm trying to help here."
    s "Take the cheap stuff now, I guarantee you'll be back in six months buying the premium stuff *and* another engine."
    menu:
        "Well I definitely don't want to buy two engines. I guess I'll go for premium":
            jump takePremium
        "I want regular":
            s "Oh fine! Some people just won't accept advice..."
            jump beginRegularSell

label beginRegularSell:
    s "So 250ml of regular Y-Gas will be 600 credits."
    menu:
        "I was thinking more along the lines of 50 credits":
            jump YGasCrazyLow
        "Done":
            jump YGasHighestPrice
        "That's a little much for Y-Gas, surely. What's the best price you can give me?":
            jump YGasAskBestPrice
        "I'll take it off your hands for 400 credits":
            jump YGasAssertiveDiscount
        "Can you knock anything off that price?":
            jump YGasAskForSomeDiscount
            
label YGasCrazyLow:
    s "Oh come on, you can't be serious. Thats a ludicrous price."
    s "I know you're not from around here, but surely you must have some idea of how much fuel costs."
    s "If I sold it at 50 credits I might as well give up on running a business right now. No, 600 is as low as I can sell and still feed myself."
    menu:
        "600 credits is an insane price for fuel and you know it! You 'outer-system' types are all the same - swindling people who aren't from around here.":
            jump racistRemark
        "Lets call it 75 credits then":
            jump YGasStillTooLowLoseInterest
        "Fine, I'll take the gas for 600 credits":
            jump YGasHighestPrice

label racistRemark:
    s "Excuse me?"
    s "Get out of my store before I kick you out, you bigoted jerk."
    jump thrownOutEnding

label YGasStillTooLowLoseInterest:
    s "Oh I don't have time for this."
    s "You're a Trans-Lyria trader. There's no way you don't know the price of fuel. Is this a joke?"
    s "I've other business to attend to, so just leave. Don't bother wasting any more of my time."
    s "Maybe you can dig for some free fuel outside."
    jump disinterestEnding

label YGasHighestPrice:
    play sound "sounds/kaChing.mp3"
    $ y_gas = True
    $ y_gas_price = 600
    
    s "That's a great price you're getting too."
    s "I'm telling you, you'd need double that amount of gas to travel within distance of another place with better rates than here."
    s "Can I get you anything else?"
    jump buyingOptions

label YGasAskBestPrice:
    s "You seem like a decent person, but there's only so far I can discount fuel before I start running at a loss."
    s "The absoulte best I can do is probably 550 credits."
    menu:
        "You've got a deal":
            jump YGasBuyAtSellersBest
        "How about 450 credit?":
            jump pushingBestPrice

label YGasBuyAtSellersBest:
    play sound "sounds/kaChing.mp3"
    s "Now, don't tell anyone else my best price or they'll all be kicking my door down for discounts!"
    s "Anything else?"
    $ y_gas = True
    $ y_gas_price = 550
    jump buyingOptions

label pushingBestPrice:
    s "So let me get this straight:"
    s "You ask a person for their best price,"
    s "Then when they give you it, you ask if they can go lower?"
    s "I don't know where you're from, but around here that's pretty rude."
    s "I've given you the best price I can do, take it or leave it."
    menu:
        "I guess I'll take it then":
            jump YGasBuyAtSellersBest


label YGasAssertiveDiscount:
    s "I can't do that. Come on friend, you know what the rates for Y-Gas are like this year! I have to make a living, same as you."
    s "I tell you what, what about 450 credits? Now at that price it's practically theft, but I aim to please."
    menu:
        "Come on, surely you'll let me steal a tiny bit more than that from you!":
            jump YGasSecondAssertive
        "Oh it's hardly theft is it? It's a reasonable price and I'm happy to buy at that price":
            jump YGasBuyAtFirstAssertive
        "With a price like that I might come back to rob you again. You've got yourself a deal":
            jump YGasBuyAtFirstAssertive

label YGasBuyAtFirstAssertive:
    play sound "sounds/kaChing.mp3"
    s "Well at any rate you're certainly reluctant to part with credits."
    s "Anything else I can get for you?"
    $ y_gas = True
    $ y_gas_price = 450
    jump buyingOptions

label YGasSecondAssertive:
    s "Oh fine then! 400 if it will get you out of my shop before close."
    s "You really know how to squeeze a fellow."
    menu:
        "400 it is":
            jump YGasBuyAtSecondAssertive
        "Don't suppose you can knock any more off that price?":
            jump YGasTooAssertive

label YGasTooAssertive:
    s "No, that's as far as I'm willing to go today I'm afraid."
    menu:
        "400 it is":
            jump YGasBuyAtSecondAssertive
            
label YGasBuyAtSecondAssertive:
    play sound "sounds/kaChing.mp3"
    s "I hope you remember the favour I've done you here"
    s "You get any other traders back home looking for parts, remember and send them here yea?"
    s "Now, can I get you anything else?"
    $ y_gas = True
    $ y_gas_price = 400
    jump buyingOptions
    
label YGasAskForSomeDiscount:
    s "Well fuel isn't traditionally something you get a \"discount\" on is it? It's hardly a big ticket luxury item."
    s "Seeing as you had the entreprenurial spirit to try, I'll knock 50 credits off the price just for you."
    menu:
        "I just love a good bargain, and you seem like the kind of maverick businessman that will ignore traditions that get in the way of a good sale. Lets say 450 yeah?":
            jump YGasFunDiscount
        "Could you give me another discount?":
            jump YGasWeakDiscount
        "I knew you would be able to knock something off, I'll take it at the discounted price":
            jump YGasBuySomeDiscount

label YGasFunDiscount:
    s "You're quite the charmer. I like your style."
    s "Fine, 450 credits, deal?"
    m "Deal."
    s "Great! Anything else?"
    jump buyingOptions

label YGasWeakDiscount:
    s "I told you, I don't even usually give a discount on fuel. I've given you a more than fair price. Take it or leave it."
    menu:
        "Well, I guess I'll take it":
            "Wise choice. Now, can I offer you anything else?"
            jump buyingOptions
    
label YGasBuySomeDiscount:
    play sound "sounds/kaChing.mp3"
    s "Well, I am a generous businessman. Always helping out off-world traders with great deals."
    s "Can I help you with anything else?"
    $ y_gas = True
    $ y_gas_price = 550
    jump buyingOptions