#Outline for space haggling game

You stop off on a market planet on your way to your main
destination. You have some sort of delivery to make, but need three
items:

- Big purchase item: Dimensional compressor
- Mid Level purchase: 250ml cylinder of Y-Gas
- Inconsequential purchase: 2 zrwg connectors

Opening line, welcomes you in as a friend and also offers something
you don't need. Can get straight to business, ask about his day, or
buy the inconsequential item.

Do the inconsequential item first. You just have to buy these for the
price they are. Tactics are also to try haggling, but you shouldn't be
able to do this. This is fine, but don't push for it, otherwise you
will shut the shopkeeper down from further negotiations. You can also
massively insult him here in which case he will just kick you out.

The mid level one is a bit more flexible. You shouldn't be able to do
the full gammut of haggling tactics here. For the most part, your
discount should be minor, as this is a raw material good. Maybe he
tries to swindle you with a premium version. Maybe put in 3 or 4 from
the tips and mistakes part here, to different effects.

For the top level item, you want the full gammut of options, the
seller will pull out all their stops and you can also bargain for
additional items.

Fail states:
- Not getting all the items.
- Getting kicked out of the shop.
- Paying a huge markup which leaves you unable to pay the main fair
- Agreeing to a price which you are unable to pay

Not so great states:
- Bargaining for excess junk
- Getting add ons for the minor item instead of the mid level one
- Getting a decent discount, but not as much as you could have

Good endings:
- Maximally pullling out all the stops and getting a minimum price
- Negotiating well for add ons then pushing further with that one
- Bargaining for useful things *not* on the table. Can you get out of
  paying the toll too?

#Mistakes that could be made
1. Being a snob
2. Being impolite/disrespectful
3. Being a racist
4. Implying that they are a thief of untrustworthy
5. Not having the will or patience to keep at it
6. Not pushing at price when you could
7. Falling for the sob story/other tricks - Imagine owning, limited
   availability, emotional leakage.
8. Not demonstrating adequate knowledge of the product (Can you get it
   elsewhere? What is the market price?)
9. Conversely, showing your hand and overvaluing product
10. Showing too much enthusiasm
11. Showing little to know interest, as in you don't even seem like a
buyer.
12. Letting the seller "Take over" the conversation and dominate the
    proceedings. You lose your bargaining edge.

#Tips that will move you towards a sale
1. Engage the salesperson as a human being: Ask how their day was,
speak normally and establish a rapport.
2. Don't name things, it gives them too much value
3. Be specific with your prices, precision makes it seem like a
   knowledgable thing and anchors in your favour (be prepared to back
   up your claim though...
4. Inspect the quality of the good. What is the condition like? Is it
past it's sell-by date? Don't make fun of the product tho...you *do*
want it
5. Hesitation is a powerful tool, it shows you want it but also not
enough to accept the first offer.
6. Go insultingly low if its appropriate. For a big ticket, non
artistic item it is fine.
7. Be Polite.
8. Be aware of anchoring, it is hard to get out of.
9. "What's your best price?" You can't continue to bargain after you
have said this. The negotation is in the final step now.
10. If a price is insultingly high, you can walk away remember! Don't
be afraid of this.
11. You should only haggle over significant cost. What is the point if
something is 50p?
12. If you are buying in bulk or lots of things, this is worth
something to the seller. Use this as leverage to get better deals.
13. Appealing to your poorness and sympathies can be good, but only if
    you avoid revealing your actual richness (Whatever merchant job
    you have in this should actually be an indicator of wealth. He
    will pick up on this and there is no way out. For this game at
    least, this is not a viable option).
14. Feed off the energy of the seller. If they are getting angry and
    passionate, respond in kind! As long as its in good humour, the
    performance of it helps massively.
